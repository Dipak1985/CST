﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Error Message text box field is empty please enter the valid data");
            }
            else
            {
                int second = Convert.ToInt32(textBox1.Text);
                if(second >= 60 && second <= 3599)
                {
                    int minutes = second / 60;
                    textBox2.Text = minutes + " " + "Minutes";
                }
               else if (second >= 3600 && second <= 84599)
                {
                    int hour = second / 3600;
                    textBox2.Text = hour + " " +"hours";
                }
                else if (second >= 84600)
                {
                    int days = second / 84600;
                    textBox2.Text = days + " " + "Days";
                }
                else
                {
                    textBox2.Text = second + "seconds";
                }
            }
        }
    }
}
